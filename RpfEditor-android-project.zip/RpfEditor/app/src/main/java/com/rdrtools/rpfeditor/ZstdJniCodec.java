package com.rdrtools.rpfeditor;

import com.github.luben.zstd.Zstd;

import java.io.IOException;

/** Zstandard support for Android, using the zstd-jni library. */
final class ZstdJniCodec implements RpfArchive.Codec {
    @Override
    public byte[] zstdDecompress(byte[] src, int originalSize) throws IOException {
        try {
            return Zstd.decompress(src, originalSize);
        } catch (RuntimeException ex) {
            throw new IOException("Zstandard decompression failed: " + ex.getMessage());
        }
    }

    @Override
    public byte[] zstdCompress(byte[] src, int level) throws IOException {
        try {
            return Zstd.compress(src, level);
        } catch (RuntimeException ex) {
            throw new IOException("Zstandard compression failed: " + ex.getMessage());
        }
    }
}
