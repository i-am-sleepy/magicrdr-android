package com.rdrtools.rpfeditor;

import java.io.ByteArrayOutputStream;
import java.io.Closeable;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.RandomAccessFile;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.zip.DataFormatException;
import java.util.zip.Deflater;
import java.util.zip.Inflater;

import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;

/**
 * Reader / in-place editor for Red Dead Redemption "RPF6" archives.
 * Format knowledge comes from the Magic RDR source (RPF6.cs / DataUtils.cs).
 *
 * Pure Java (no Android classes) so it can be tested on a normal JVM.
 */
public final class RpfArchive implements Closeable {

    /** Zstandard is supplied by the caller (zstd-jni on Android). */
    public interface Codec {
        byte[] zstdDecompress(byte[] src, int originalSize) throws IOException;
        byte[] zstdCompress(byte[] src, int level) throws IOException;
    }

    public interface Progress {
        void onProgress(int done, int total, String what);
    }

    private static final int MAGIC = 0x52504636; // "RPF6"
    private static final int ENTRY_SIZE = 20;
    private static final int HEADER_SIZE = 16;
    private static final int ZSTD_LEVEL = 10;

    private static final int[] KEY_INTS = {
        0xB7, 0x62, 0xDF, 0xB6, 0xE2, 0xB2, 0xC6, 0xDE, 0xAF, 0x72, 0x2A, 0x32, 0xD2, 0xFB, 0x6F, 0x0C,
        0x98, 0xA3, 0x21, 0x74, 0x62, 0xC9, 0xC4, 0xED, 0xAD, 0xAA, 0x2E, 0xD0, 0xDD, 0xF9, 0x2F, 0x10
    };

    public static final class Entry {
        public final int index;
        public final boolean directory;
        public final long nameHash;          // unsigned 32-bit value
        public long sizeInArchive;           // bytes stored in the archive
        public long offset;                  // byte offset of the stored data
        public int flag1;
        public int flag2;
        public int firstChild;               // directories only
        public int childCount;               // directories only
        public String name;                  // recovered name, or null

        Entry(int index, boolean directory, long nameHash) {
            this.index = index;
            this.directory = directory;
            this.nameHash = nameHash;
        }

        /** Resource files (textures/models in console format) can only be exported, not replaced. */
        public boolean isResource() { return !directory && (flag1 & 0x80000000) != 0; }

        public boolean isCompressed() { return !directory && !isResource() && (flag1 & 0x40000000) != 0; }

        /** Size of the file after decompression (regular files only). */
        public int totalSize() { return flag1 & 0xBFFFFFFF; }

        public String hashText() { return String.format("0x%08X", nameHash); }

        public String displayName() { return name != null ? name : hashText(); }
    }

    private final File file;
    private final Codec codec;
    private RandomAccessFile raf;
    private int entryCount;
    private int debugField;
    private int encFlag;
    private byte[] tocDecrypted;
    private final List<Entry> entries = new ArrayList<Entry>();
    private boolean usesZstd = true;

    private RpfArchive(File file, Codec codec) {
        this.file = file;
        this.codec = codec;
    }

    public static RpfArchive open(File file, Codec codec) throws IOException {
        RpfArchive a = new RpfArchive(file, codec);
        a.load();
        return a;
    }

    public File getFile() { return file; }

    public List<Entry> getEntries() { return entries; }

    public boolean isEncryptedToc() { return encFlag != 0; }

    public boolean usesZstd() { return usesZstd; }

    // ------------------------------------------------------------------ loading

    private void load() throws IOException {
        if (raf != null) { raf.close(); raf = null; }
        entries.clear();
        raf = new RandomAccessFile(file, "r");
        if (raf.length() < HEADER_SIZE) throw new IOException("File is too small to be an RPF archive.");
        byte[] head = new byte[HEADER_SIZE];
        raf.seek(0);
        raf.readFully(head);
        ByteBuffer hb = ByteBuffer.wrap(head).order(ByteOrder.BIG_ENDIAN);
        if (hb.getInt(0) != MAGIC) {
            throw new IOException("This is not an RPF6 archive (the Red Dead Redemption format).");
        }
        entryCount = hb.getInt(4);
        debugField = hb.getInt(8);
        encFlag = hb.getInt(12);
        if (entryCount <= 0 || entryCount > 5000000) throw new IOException("Archive header looks damaged.");

        long tocSize = ((long) entryCount * ENTRY_SIZE + 15L) & ~15L;
        if (HEADER_SIZE + tocSize > raf.length()) throw new IOException("Archive is truncated.");
        byte[] toc = new byte[(int) tocSize];
        raf.seek(HEADER_SIZE);
        raf.readFully(toc);
        tocDecrypted = (encFlag != 0) ? aes16(toc, true) : toc;

        ByteBuffer tb = ByteBuffer.wrap(tocDecrypted).order(ByteOrder.BIG_ENDIAN);
        for (int i = 0; i < entryCount; i++) {
            int b = i * ENTRY_SIZE;
            long hash = tb.getInt(b) & 0xFFFFFFFFL;
            boolean dir = (tocDecrypted[b + 8] & 0xFF) == 0x80;
            Entry e = new Entry(i, dir, hash);
            if (dir) {
                e.flag1 = tb.getInt(b + 4);
                e.firstChild = tb.getInt(b + 8) & 0x7FFFFFFF;
                e.childCount = tb.getInt(b + 12) & 0x0FFFFFFF;
            } else {
                e.sizeInArchive = tb.getInt(b + 4) & 0x0FFFFFFFL;
                int off = tb.getInt(b + 8);
                e.flag1 = tb.getInt(b + 12);
                e.flag2 = tb.getInt(b + 16);
                if (e.isResource()) {
                    e.offset = (off & 0x7FFFFF00L) * 8L;
                } else {
                    e.offset = (off & 0x7FFFFFFFL) * 8L;
                }
            }
            entries.add(e);
        }

        // Work out which compression this archive uses (PC / Switch = Zstandard, older = Deflate).
        usesZstd = true;
        for (Entry e : entries) {
            if (e.isCompressed() && e.sizeInArchive >= 4) {
                byte[] first = readRange(e.offset, 4);
                usesZstd = isZstd(first);
                break;
            }
        }
    }

    /** Re-reads the archive from disk (used after saving). */
    public synchronized void reload() throws IOException {
        Map<Long, String> oldNames = new HashMap<Long, String>();
        for (Entry e : entries) if (e.name != null) oldNames.put(e.nameHash, e.name);
        load();
        for (Entry e : entries) {
            String n = oldNames.get(e.nameHash);
            if (n != null) e.name = n;
        }
    }

    @Override
    public synchronized void close() throws IOException {
        if (raf != null) { raf.close(); raf = null; }
    }

    // ------------------------------------------------------------------ reading

    private synchronized byte[] readRange(long off, int len) throws IOException {
        byte[] buf = new byte[len];
        raf.seek(off);
        raf.readFully(buf);
        return buf;
    }

    /** The bytes exactly as stored in the archive. */
    public synchronized byte[] readStored(Entry e) throws IOException {
        if (e.directory) throw new IOException("That is a folder, not a file.");
        if (e.sizeInArchive > 400L * 1024 * 1024) throw new IOException("File is too large to load on a phone.");
        if (e.offset + e.sizeInArchive > raf.length()) throw new IOException("Entry points outside the archive.");
        return readRange(e.offset, (int) e.sizeInArchive);
    }

    /** The file content, decompressed when the archive stores it compressed. */
    public synchronized byte[] readContent(Entry e) throws IOException {
        byte[] stored = readStored(e);
        if (!e.isCompressed()) return stored;
        if (isZstd(stored)) return codec.zstdDecompress(stored, e.totalSize());
        return inflateRaw(stored, e.totalSize());
    }

    // ------------------------------------------------------------------ writing

    /** Makes a one-time copy "name.rpf.bak" next to the archive. */
    public File ensureBackup() throws IOException {
        File bak = new File(file.getParentFile(), file.getName() + ".bak");
        if (bak.exists()) return bak;
        InputStream in = new FileInputStream(file);
        try {
            OutputStream out = new FileOutputStream(bak);
            try {
                byte[] buf = new byte[1 << 16];
                int n;
                while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
            } finally {
                out.close();
            }
        } finally {
            in.close();
        }
        return bak;
    }

    /**
     * Writes the given replacement contents (entry index -> new file bytes) into the archive file.
     * Untouched files stay byte-for-byte identical; larger files are appended at the end.
     */
    public synchronized void save(Map<Integer, byte[]> replacements, Progress progress) throws IOException {
        if (replacements.isEmpty()) return;

        // Which stored offsets are used by more than one entry? (must not be overwritten in place)
        Map<Long, Integer> offsetUse = new HashMap<Long, Integer>();
        for (Entry e : entries) {
            if (e.directory) continue;
            Integer c = offsetUse.get(e.offset);
            offsetUse.put(e.offset, c == null ? 1 : c + 1);
        }

        byte[] toc = tocDecrypted.clone();
        RandomAccessFile rw = new RandomAccessFile(file, "rw");
        try {
            long fileLen = rw.length();
            int done = 0;
            for (Map.Entry<Integer, byte[]> r : replacements.entrySet()) {
                Entry e = entries.get(r.getKey());
                byte[] content = r.getValue();
                if (e.directory) throw new IOException("Cannot replace a folder.");
                if (e.isResource()) throw new IOException(e.displayName() + " is a resource file; it can only be exported.");
                if (content.length == 0) throw new IOException("A replacement file cannot be empty (" + e.displayName() + ").");
                if (content.length >= (1 << 29)) throw new IOException("Replacement file is too large.");
                if (progress != null) progress.onProgress(done, replacements.size(), e.displayName());

                byte[] stored = e.isCompressed() ? compress(content) : content;
                long newOffset;
                boolean shared = offsetUse.get(e.offset) != null && offsetUse.get(e.offset) > 1;
                if (!shared && stored.length <= e.sizeInArchive) {
                    newOffset = e.offset;
                    rw.seek(newOffset);
                    rw.write(stored);
                    long tail = e.sizeInArchive - stored.length;
                    if (tail > 0) writeZeros(rw, tail);
                } else {
                    long align = stored.length >= 131072 ? 2048L : 8L;
                    newOffset = roundUp(fileLen, align);
                    rw.seek(fileLen);
                    writeZeros(rw, newOffset - fileLen);
                    rw.write(stored);
                    fileLen = newOffset + stored.length;
                }

                int base = e.index * ENTRY_SIZE;
                ByteBuffer tb = ByteBuffer.wrap(toc).order(ByteOrder.BIG_ENDIAN);
                int oldSizeField = tb.getInt(base + 4);
                int oldOffField = tb.getInt(base + 8);
                int oldFlag1 = tb.getInt(base + 12);
                tb.putInt(base + 4, (oldSizeField & 0xF0000000) | stored.length);
                tb.putInt(base + 8, (oldOffField & 0x80000000) | (int) (newOffset / 8L));
                tb.putInt(base + 12, (oldFlag1 & 0x40000000) | content.length);
                done++;
            }

            // keep the file length a multiple of 2048 like the original
            long padded = roundUp(fileLen, 2048L);
            if (padded > fileLen) {
                rw.seek(fileLen);
                writeZeros(rw, padded - fileLen);
            }

            // finally write the table of contents (last, so a crash earlier leaves the old TOC intact)
            byte[] out = (encFlag != 0) ? aes16(toc, false) : toc;
            rw.seek(HEADER_SIZE);
            rw.write(out);
            rw.getFD().sync();
        } finally {
            rw.close();
        }
        reload();
    }

    // ------------------------------------------------------------------ helpers

    private byte[] compress(byte[] content) throws IOException {
        if (usesZstd) return codec.zstdCompress(content, ZSTD_LEVEL);
        Deflater d = new Deflater(9, true);
        try {
            d.setInput(content);
            d.finish();
            ByteArrayOutputStream bos = new ByteArrayOutputStream(content.length / 2 + 64);
            byte[] buf = new byte[1 << 16];
            while (!d.finished()) {
                int n = d.deflate(buf);
                bos.write(buf, 0, n);
            }
            return bos.toByteArray();
        } finally {
            d.end();
        }
    }

    private static byte[] inflateRaw(byte[] data, int size) throws IOException {
        Inflater inf = new Inflater(true);
        try {
            inf.setInput(data);
            byte[] out = new byte[size];
            int pos = 0;
            while (pos < size) {
                int n = inf.inflate(out, pos, size - pos);
                if (n == 0 && (inf.finished() || inf.needsInput() || inf.needsDictionary())) break;
                pos += n;
            }
            if (pos != size) throw new IOException("Unexpected end of compressed data.");
            return out;
        } catch (DataFormatException ex) {
            throw new IOException("Unknown compression format: " + ex.getMessage());
        } finally {
            inf.end();
        }
    }

    public static boolean isZstd(byte[] b) {
        return b.length >= 4 && (b[0] & 0xFF) == 0x28 && (b[1] & 0xFF) == 0xB5
                && (b[2] & 0xFF) == 0x2F && (b[3] & 0xFF) == 0xFD;
    }

    private static void writeZeros(RandomAccessFile f, long count) throws IOException {
        byte[] z = new byte[(int) Math.min(count, 1 << 16)];
        while (count > 0) {
            int n = (int) Math.min(count, z.length);
            f.write(z, 0, n);
            count -= n;
        }
    }

    private static long roundUp(long v, long align) {
        long r = v % align;
        return r == 0 ? v : v + (align - r);
    }

    /** Rockstar's file-name hash (lower-cased one-at-a-time hash), same as DataUtils.GetHash in Magic RDR. */
    public static long hashName(String s) {
        int h = 0;
        String low = s.toLowerCase(java.util.Locale.ROOT);
        for (int i = 0; i < low.length(); i++) {
            h += low.charAt(i);
            h += (h << 10);
            h ^= (h >>> 6);
        }
        h += (h << 3);
        h ^= (h >>> 11);
        h += (h << 15);
        return h & 0xFFFFFFFFL;
    }

    private static byte[] aes16(byte[] data, boolean decrypt) throws IOException {
        try {
            byte[] key = new byte[KEY_INTS.length];
            for (int i = 0; i < key.length; i++) key[i] = (byte) KEY_INTS[i];
            byte[] buf = data.clone();
            int n = buf.length & ~15;
            if (n == 0) return buf;
            Cipher c = Cipher.getInstance("AES/ECB/NoPadding");
            c.init(decrypt ? Cipher.DECRYPT_MODE : Cipher.ENCRYPT_MODE, new SecretKeySpec(key, "AES"));
            for (int pass = 0; pass < 16; pass++) {
                byte[] tmp = c.doFinal(buf, 0, n);
                System.arraycopy(tmp, 0, buf, 0, n);
            }
            return buf;
        } catch (java.security.GeneralSecurityException ex) {
            throw new IOException("Encryption problem: " + ex.getMessage());
        }
    }
}
