package com.rdrtools.rpfeditor;

import java.nio.charset.Charset;

/** Works out what a file inside an RPF is (text, XML, texture...) and tries to recover its real name. */
public final class Analyzer {

    public static final Charset LATIN1 = Charset.forName("ISO-8859-1");

    public static final class Info {
        public String kind = "Data";
        public String ext = ".bin";
        public boolean text = false;
        public String preview = "";
        public String recoveredName = null;
    }

    private Analyzer() { }

    public static Info analyze(byte[] data, long nameHash) {
        Info info = new Info();
        if (data == null || data.length == 0) { info.kind = "Empty"; return info; }

        if (data.length >= 4 && (data[0] & 0xFF) == 0xAB && data[1] == 'K' && data[2] == 'T' && data[3] == 'X') {
            info.kind = "KTX texture"; info.ext = ".ktx"; return info;
        }
        if (data.length >= 4 && data[0] == 'D' && data[1] == 'D' && data[2] == 'S' && data[3] == ' ') {
            info.kind = "DDS texture"; info.ext = ".dds"; return info;
        }
        if (data.length >= 8 && (data[0] & 0xFF) == 0x89 && data[1] == 'P' && data[2] == 'N' && data[3] == 'G') {
            info.kind = "PNG image"; info.ext = ".png"; return info;
        }
        if (data.length >= 3 && (data[0] & 0xFF) == 0xFF && (data[1] & 0xFF) == 0xD8 && (data[2] & 0xFF) == 0xFF) {
            info.kind = "JPEG image"; info.ext = ".jpg"; return info;
        }

        if (looksLikeText(data)) {
            info.text = true;
            int n = Math.min(data.length, 160);
            String head = new String(data, 0, n, LATIN1);
            info.preview = oneLine(head);
            String trimmed = head.trim();
            if (trimmed.startsWith("<?xml") || trimmed.startsWith("<")) {
                info.kind = "XML text"; info.ext = ".xml";
            } else if (trimmed.startsWith("mtl ")) {
                info.kind = "Material"; info.ext = ".mtl";
                String firstLine = trimmed.split("[\\r\\n]")[0];
                String candidate = firstLine.substring(4).trim();
                if (!candidate.isEmpty() && RpfArchive.hashName(candidate + ".mtl") == nameHash) {
                    info.recoveredName = candidate + ".mtl";
                }
            } else {
                info.kind = "Text"; info.ext = ".txt";
            }
            return info;
        }
        info.kind = "Binary data";
        info.ext = ".bin";
        return info;
    }

    /** True when the file is (almost) all printable text, so it is safe to show in the editor. */
    public static boolean looksLikeText(byte[] data) {
        int n = Math.min(data.length, 4096);
        if (n == 0) return false;
        int odd = 0;
        for (int i = 0; i < n; i++) {
            int b = data[i] & 0xFF;
            if (b == 0) return false;
            if (b < 9 || (b > 13 && b < 32)) odd++;
        }
        return odd * 100 / n < 2;
    }

    private static String oneLine(String s) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            sb.append(c < 32 ? ' ' : c);
        }
        return sb.toString().replaceAll(" +", " ").trim();
    }
}
