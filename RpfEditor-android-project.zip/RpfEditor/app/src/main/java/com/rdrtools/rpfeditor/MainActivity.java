package com.rdrtools.rpfeditor;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.ActivityNotFoundException;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.text.Editable;
import android.text.InputType;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

/**
 * RPF Editor - a small Android tool for opening Red Dead Redemption .rpf archives,
 * exporting their files, editing text files and replacing files, then saving the
 * changes back into the same .rpf in the same folder.
 */
public class MainActivity extends Activity {

    private static final int MODE_PERMISSION = 0;
    private static final int MODE_BROWSER = 1;
    private static final int MODE_ARCHIVE = 2;

    private static final int PURPOSE_OPEN = 0;
    private static final int PURPOSE_REPLACE = 1;

    private interface Status { void say(String message); }

    private interface Work { String run(Status status) throws Exception; }

    private final Handler ui = new Handler(Looper.getMainLooper());
    private final RpfArchive.Codec codec = new ZstdJniCodec();

    private LinearLayout root;
    private int mode = MODE_PERMISSION;
    private int purpose = PURPOSE_OPEN;
    private int replaceTarget = -1;
    private File currentDir;

    private RpfArchive archive;
    private final Map<Integer, byte[]> pending = new LinkedHashMap<Integer, byte[]>();
    private final Map<Integer, Analyzer.Info> infos = new ConcurrentHashMap<Integer, Analyzer.Info>();
    private final List<RpfArchive.Entry> shown = new ArrayList<RpfArchive.Entry>();
    private String filter = "";
    private Set<Integer> contentMatches = null;
    private volatile boolean busy = false;
    private volatile boolean scanning = false;
    private int scanGeneration = 0;

    private TextView titleView;
    private TextView statusView;
    private Button saveButton;
    private BaseAdapter archiveAdapter;

    // ================================================================== lifecycle

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        int p = dp(12);
        root.setPadding(p, p, p, p);
        setContentView(root);
        decideStart();
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (mode == MODE_PERMISSION && hasAccess()) decideStart();
    }

    @Override
    protected void onDestroy() {
        scanGeneration++;
        super.onDestroy();
    }

    private void decideStart() {
        if (hasAccess()) {
            if (currentDir == null) currentDir = Environment.getExternalStorageDirectory();
            showBrowser();
        } else {
            showPermission();
        }
    }

    // ================================================================== permission

    private boolean hasAccess() {
        if (Build.VERSION.SDK_INT >= 30) {
            return Environment.isExternalStorageManager();
        }
        return checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED;
    }

    private void requestAccess() {
        if (Build.VERSION.SDK_INT >= 30) {
            try {
                Intent i = new Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION,
                        Uri.parse("package:" + getPackageName()));
                startActivity(i);
            } catch (ActivityNotFoundException ex) {
                startActivity(new Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION));
            }
        } else {
            requestPermissions(new String[] {
                    Manifest.permission.READ_EXTERNAL_STORAGE,
                    Manifest.permission.WRITE_EXTERNAL_STORAGE }, 1);
        }
    }

    private void showPermission() {
        mode = MODE_PERMISSION;
        root.removeAllViews();
        root.addView(title("RPF Editor"));
        TextView t = text("To open an .rpf file and save your changes back into the same folder, "
                + "this app needs the \"All files access\" permission.\n\n"
                + "Tap the button, switch the permission ON for RPF Editor, then press Back to return here.", 15);
        t.setPadding(0, dp(12), 0, dp(12));
        root.addView(t);
        root.addView(button("Allow access to all files", new View.OnClickListener() {
            @Override public void onClick(View v) { requestAccess(); }
        }));
    }

    // ================================================================== file browser

    private void showBrowser() {
        mode = MODE_BROWSER;
        root.removeAllViews();
        root.addView(title(purpose == PURPOSE_OPEN
                ? "Choose an .rpf file"
                : "Choose the file to put into the archive"));
        TextView path = text(currentDir.getAbsolutePath(), 12);
        path.setTextColor(Color.DKGRAY);
        path.setPadding(0, 0, 0, dp(6));
        root.addView(path);

        final List<File> items = new ArrayList<File>();
        final List<String> labels = new ArrayList<String>();
        File parent = currentDir.getParentFile();
        if (parent != null) {
            items.add(parent);
            labels.add("\u2B06  Go up one folder");
        }
        File[] list = currentDir.listFiles();
        if (list == null) {
            TextView warn = text("This folder cannot be read. (Android blocks the Android/data and Android/obb "
                    + "folders. Copy your .rpf file to another folder such as Download, then open it from there.)", 13);
            warn.setTextColor(Color.RED);
            root.addView(warn);
        } else {
            Arrays.sort(list, new java.util.Comparator<File>() {
                @Override public int compare(File a, File b) {
                    if (a.isDirectory() != b.isDirectory()) return a.isDirectory() ? -1 : 1;
                    return a.getName().compareToIgnoreCase(b.getName());
                }
            });
            for (File f : list) {
                if (f.isDirectory()) {
                    items.add(f);
                    labels.add("\uD83D\uDCC1  " + f.getName());
                } else if (purpose == PURPOSE_REPLACE
                        || f.getName().toLowerCase(Locale.ROOT).endsWith(".rpf")) {
                    items.add(f);
                    labels.add(f.getName() + "   (" + fmtSize(f.length()) + ")");
                }
            }
        }
        ListView lv = new ListView(this);
        lv.setAdapter(new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, labels));
        lv.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parentView, View view, int position, long id) {
                File f = items.get(position);
                if (f.isDirectory()) {
                    currentDir = f;
                    showBrowser();
                } else if (purpose == PURPOSE_OPEN) {
                    openArchive(f);
                } else {
                    pickReplacement(f);
                }
            }
        });
        root.addView(lv, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));
        if (purpose == PURPOSE_REPLACE) {
            root.addView(button("Cancel", new View.OnClickListener() {
                @Override public void onClick(View v) { cancelReplace(); }
            }));
        }
    }

    private void cancelReplace() {
        purpose = PURPOSE_OPEN;
        replaceTarget = -1;
        showArchive();
    }

    private void pickReplacement(File f) {
        try {
            if (f.length() == 0) { toast("That file is empty."); return; }
            if (f.length() > 100L * 1024 * 1024) { toast("That file is too large (over 100 MB)."); return; }
            byte[] data = readAll(f);
            pending.put(replaceTarget, data);
            toast("Replacement chosen (" + f.getName() + "). Tap \"Save changes\" when you are finished.");
        } catch (IOException ex) {
            toast("Could not read that file: " + ex.getMessage());
            return;
        }
        purpose = PURPOSE_OPEN;
        replaceTarget = -1;
        showArchive();
    }

    // ================================================================== opening an archive

    private void openArchive(File f) {
        try {
            closeArchive();
            archive = RpfArchive.open(f, codec);
        } catch (Exception ex) {
            archive = null;
            toast("Cannot open this file: " + ex.getMessage());
            return;
        }
        pending.clear();
        infos.clear();
        filter = "";
        contentMatches = null;
        currentDir = f.getParentFile();
        showArchive();
        startScan();
    }

    private void closeArchive() {
        scanGeneration++;
        scanning = false;
        if (archive != null) {
            try { archive.close(); } catch (IOException ignored) { }
            archive = null;
        }
        pending.clear();
        infos.clear();
    }

    /** Reads every file once to find out what it is (text, XML, texture...) and to recover names. */
    private void startScan() {
        final int gen = ++scanGeneration;
        final RpfArchive a = archive;
        scanning = true;
        final List<RpfArchive.Entry> list = new ArrayList<RpfArchive.Entry>(a.getEntries());
        int count = 0;
        for (RpfArchive.Entry e : list) if (!e.directory) count++;
        final int totalFiles = count;
        setStatus("Reading files\u2026 0/" + totalFiles);
        new Thread(new Runnable() {
            @Override public void run() {
                int n = 0;
                for (RpfArchive.Entry e : list) {
                    if (gen != scanGeneration) return;
                    if (e.directory) continue;
                    Analyzer.Info info;
                    if (e.isResource()) {
                        info = new Analyzer.Info();
                        info.kind = "Resource (export only)";
                        info.ext = ".rsc";
                    } else {
                        try {
                            byte[] c = a.readContent(e);
                            info = Analyzer.analyze(c, e.nameHash);
                            if (info.recoveredName != null) e.name = info.recoveredName;
                        } catch (Throwable t) {
                            info = new Analyzer.Info();
                            info.kind = "Unreadable";
                        }
                    }
                    infos.put(e.index, info);
                    n++;
                    if (n % 150 == 0) {
                        final int shownCount = n;
                        ui.post(new Runnable() {
                            @Override public void run() {
                                if (gen != scanGeneration) return;
                                setStatus("Reading files\u2026 " + shownCount + "/" + totalFiles);
                                if (archiveAdapter != null) archiveAdapter.notifyDataSetChanged();
                            }
                        });
                    }
                }
                ui.post(new Runnable() {
                    @Override public void run() {
                        if (gen != scanGeneration) return;
                        scanning = false;
                        setStatus("Ready. Tap a file to view, edit, export or replace it.");
                        refreshList();
                    }
                });
            }
        }).start();
    }

    // ================================================================== archive screen

    private void showArchive() {
        mode = MODE_ARCHIVE;
        root.removeAllViews();
        titleView = title("");
        root.addView(titleView);
        statusView = text(scanning ? "Reading files\u2026" : "Ready. Tap a file to view, edit, export or replace it.", 12);
        statusView.setTextColor(Color.DKGRAY);
        statusView.setPadding(0, 0, 0, dp(6));
        root.addView(statusView);

        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        saveButton = smallButton("Save changes", new View.OnClickListener() {
            @Override public void onClick(View v) { doSave(); }
        });
        row.addView(saveButton, weight());
        row.addView(smallButton("Export all", new View.OnClickListener() {
            @Override public void onClick(View v) { exportAll(); }
        }), weight());
        row.addView(smallButton("Search inside", new View.OnClickListener() {
            @Override public void onClick(View v) { searchInside(); }
        }), weight());
        root.addView(row);

        EditText filterEdit = new EditText(this);
        filterEdit.setHint("Filter by name, hash or type");
        filterEdit.setSingleLine(true);
        filterEdit.setText(filter);
        filterEdit.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int a, int b, int c) { }
            @Override public void onTextChanged(CharSequence s, int a, int b, int c) { }
            @Override public void afterTextChanged(Editable s) {
                filter = s.toString().trim().toLowerCase(Locale.ROOT);
                refreshList();
            }
        });
        root.addView(filterEdit);

        archiveAdapter = new BaseAdapter() {
            @Override public int getCount() { return shown.size(); }
            @Override public Object getItem(int position) { return shown.get(position); }
            @Override public long getItemId(int position) { return shown.get(position).index; }
            @Override public View getView(int position, View convertView, ViewGroup parentView) {
                LinearLayout rowView;
                TextView[] tv;
                if (convertView == null) {
                    rowView = new LinearLayout(MainActivity.this);
                    rowView.setOrientation(LinearLayout.VERTICAL);
                    rowView.setPadding(dp(8), dp(8), dp(8), dp(8));
                    TextView t1 = new TextView(MainActivity.this);
                    t1.setTextSize(15);
                    t1.setTypeface(Typeface.DEFAULT_BOLD);
                    TextView t2 = new TextView(MainActivity.this);
                    t2.setTextSize(12);
                    t2.setTextColor(Color.DKGRAY);
                    t2.setMaxLines(2);
                    rowView.addView(t1);
                    rowView.addView(t2);
                    tv = new TextView[] { t1, t2 };
                    rowView.setTag(tv);
                } else {
                    rowView = (LinearLayout) convertView;
                    tv = (TextView[]) rowView.getTag();
                }
                RpfArchive.Entry e = shown.get(position);
                Analyzer.Info info = infos.get(e.index);
                boolean staged = pending.containsKey(e.index);
                tv[0].setText((staged ? "\u270E " : "") + e.displayName());
                tv[0].setTextColor(staged ? Color.rgb(0, 120, 0) : Color.BLACK);
                String size = staged ? fmtSize(pending.get(e.index).length) + " (changed)"
                        : fmtSize(e.isCompressed() ? e.totalSize() : e.sizeInArchive);
                String kind = info == null ? "\u2026" : info.kind;
                String prev = (info == null || info.preview.isEmpty()) ? "" : "\n" + info.preview;
                tv[1].setText(kind + "  \u2022  " + size + "  \u2022  " + e.hashText() + prev);
                return rowView;
            }
        };
        ListView lv = new ListView(this);
        lv.setAdapter(archiveAdapter);
        lv.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parentView, View view, int position, long id) {
                showEntryMenu(shown.get(position));
            }
        });
        root.addView(lv, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));
        refreshList();
    }

    private void refreshList() {
        if (archive == null || archiveAdapter == null) return;
        shown.clear();
        for (RpfArchive.Entry e : archive.getEntries()) {
            if (e.directory) continue;
            if (contentMatches != null && !contentMatches.contains(e.index)) continue;
            if (!filter.isEmpty() && !searchText(e).contains(filter)) continue;
            shown.add(e);
        }
        archiveAdapter.notifyDataSetChanged();
        updateHeader();
    }

    private String searchText(RpfArchive.Entry e) {
        Analyzer.Info info = infos.get(e.index);
        String s = e.displayName() + " " + e.hashText();
        if (info != null) s += " " + info.kind + " " + info.preview;
        return s.toLowerCase(Locale.ROOT);
    }

    private void updateHeader() {
        if (titleView == null || archive == null) return;
        int files = 0;
        for (RpfArchive.Entry e : archive.getEntries()) if (!e.directory) files++;
        String extra = contentMatches != null ? "  \u2022  showing " + shown.size() + " matches" : "";
        titleView.setText(archive.getFile().getName() + "  \u2022  " + files + " files" + extra);
        if (saveButton != null) {
            saveButton.setText(pending.isEmpty() ? "Save changes" : "Save changes (" + pending.size() + ")");
            saveButton.setEnabled(!pending.isEmpty() && !busy);
        }
    }

    // ================================================================== per-file actions

    private void showEntryMenu(final RpfArchive.Entry e) {
        if (busy) { toast("Please wait\u2026"); return; }
        Analyzer.Info info = infos.get(e.index);
        final List<String> labels = new ArrayList<String>();
        final List<Runnable> actions = new ArrayList<Runnable>();
        if (!e.isResource() && (info == null || info.text)) {
            labels.add("View / edit text");
            actions.add(new Runnable() { @Override public void run() { editText(e); } });
        }
        labels.add("Export this file");
        actions.add(new Runnable() { @Override public void run() { exportOne(e); } });
        if (!e.isResource()) {
            labels.add("Replace with a file from my phone\u2026");
            actions.add(new Runnable() { @Override public void run() {
                purpose = PURPOSE_REPLACE;
                replaceTarget = e.index;
                showBrowser();
            } });
        }
        if (pending.containsKey(e.index)) {
            labels.add("Undo my change");
            actions.add(new Runnable() { @Override public void run() {
                pending.remove(e.index);
                refreshList();
            } });
        }
        labels.add("Details");
        actions.add(new Runnable() { @Override public void run() { showDetails(e); } });

        new AlertDialog.Builder(this)
                .setTitle(e.displayName())
                .setItems(labels.toArray(new String[0]), new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface d, int which) { actions.get(which).run(); }
                })
                .show();
    }

    private byte[] contentFor(RpfArchive.Entry e) throws IOException {
        byte[] staged = pending.get(e.index);
        return staged != null ? staged : archive.readContent(e);
    }

    private void editText(final RpfArchive.Entry e) {
        final byte[] data;
        try {
            data = contentFor(e);
        } catch (IOException ex) {
            toast("Could not read the file: " + ex.getMessage());
            return;
        }
        if (!Analyzer.looksLikeText(data)) {
            toast("This file is not plain text. Use Export or Replace instead.");
            return;
        }
        if (data.length > 400000) {
            toast("This text file is too large to edit on screen. Export it, edit it elsewhere, then use Replace.");
            return;
        }
        final EditText edit = new EditText(this);
        edit.setText(new String(data, Analyzer.LATIN1));
        edit.setTypeface(Typeface.MONOSPACE);
        edit.setTextSize(12);
        edit.setGravity(Gravity.TOP | Gravity.START);
        edit.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_MULTI_LINE
                | InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS);
        ScrollView sv = new ScrollView(this);
        sv.addView(edit);
        final AlertDialog dlg = new AlertDialog.Builder(this)
                .setTitle("Edit " + e.displayName())
                .setView(sv)
                .setPositiveButton("Apply", null)
                .setNegativeButton("Cancel", null)
                .create();
        dlg.show();
        dlg.getButton(DialogInterface.BUTTON_POSITIVE).setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                String s = edit.getText().toString();
                for (int i = 0; i < s.length(); i++) {
                    if (s.charAt(i) > 255) {
                        toast("Only basic Latin characters can be saved in this file.");
                        return;
                    }
                }
                byte[] nb = s.getBytes(Analyzer.LATIN1);
                if (nb.length == 0) { toast("The file cannot be empty."); return; }
                if (Arrays.equals(nb, data)) { dlg.dismiss(); toast("No changes made."); return; }
                pending.put(e.index, nb);
                dlg.dismiss();
                refreshList();
                toast("Change stored. Tap \"Save changes\" when you are finished.");
            }
        });
    }

    private void showDetails(RpfArchive.Entry e) {
        Analyzer.Info info = infos.get(e.index);
        StringBuilder sb = new StringBuilder();
        sb.append("Name: ").append(e.name != null ? e.name : "(unknown - only its hash is stored)").append('\n');
        sb.append("Hash: ").append(e.hashText()).append('\n');
        sb.append("Type: ").append(info == null ? "..." : info.kind).append('\n');
        sb.append("Stored size: ").append(e.sizeInArchive).append(" bytes\n");
        if (e.isCompressed()) sb.append("Size after unpacking: ").append(e.totalSize()).append(" bytes\n");
        sb.append("Compressed: ").append(e.isCompressed() ? "yes" : "no").append('\n');
        sb.append("Resource file: ").append(e.isResource() ? "yes (export only)" : "no").append('\n');
        sb.append("Position in archive: ").append(e.offset).append('\n');
        sb.append("Table entry #").append(e.index);
        new AlertDialog.Builder(this).setTitle("Details").setMessage(sb.toString())
                .setPositiveButton("OK", null).show();
    }

    // ================================================================== export

    private File exportDir() {
        String base = archive.getFile().getName();
        int dot = base.lastIndexOf('.');
        if (dot > 0) base = base.substring(0, dot);
        return new File(archive.getFile().getParentFile(), base + "_extracted");
    }

    private String exportName(RpfArchive.Entry e) {
        String base = e.name != null ? e.name : String.format("%08X", e.nameHash);
        if (e.name == null || e.name.indexOf('.') < 0) {
            Analyzer.Info info = infos.get(e.index);
            base += (info != null ? info.ext : (e.isResource() ? ".rsc" : ".bin"));
        }
        return base.replaceAll("[\\\\/:*?\"<>|]", "_");
    }

    private void exportOne(final RpfArchive.Entry e) {
        runBusy("Exporting", new Work() {
            @Override public String run(Status status) throws Exception {
                File dir = exportDir();
                if (!dir.exists() && !dir.mkdirs()) throw new IOException("Cannot create folder " + dir);
                File out = new File(dir, exportName(e));
                writeAll(out, contentFor(e));
                return "Exported to " + out.getAbsolutePath();
            }
        }, null);
    }

    private void exportAll() {
        runBusy("Exporting all files", new Work() {
            @Override public String run(Status status) throws Exception {
                File dir = exportDir();
                if (!dir.exists() && !dir.mkdirs()) throw new IOException("Cannot create folder " + dir);
                int total = 0;
                for (RpfArchive.Entry e : archive.getEntries()) if (!e.directory) total++;
                int n = 0, failed = 0;
                for (RpfArchive.Entry e : archive.getEntries()) {
                    if (e.directory) continue;
                    try {
                        writeAll(new File(dir, exportName(e)), contentFor(e));
                    } catch (Exception ex) {
                        failed++;
                    }
                    n++;
                    if (n % 25 == 0) status.say("Exporting\u2026 " + n + "/" + total);
                }
                return "Exported " + (n - failed) + " files to " + dir.getAbsolutePath()
                        + (failed > 0 ? " (" + failed + " could not be read)" : "");
            }
        }, null);
    }

    // ================================================================== search inside files

    private void searchInside() {
        if (busy) { toast("Please wait\u2026"); return; }
        if (scanning) { toast("Still reading the archive - try again in a moment."); return; }
        final EditText input = new EditText(this);
        input.setSingleLine(true);
        input.setHint("Text to look for (ignores capital letters)");
        new AlertDialog.Builder(this)
                .setTitle("Search inside all files")
                .setView(input)
                .setPositiveButton("Search", new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface d, int w) {
                        runSearch(input.getText().toString());
                    }
                })
                .setNeutralButton("Show all files", new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface d, int w) {
                        contentMatches = null;
                        refreshList();
                    }
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    private void runSearch(final String query) {
        final String needle = query.toLowerCase(Locale.ROOT);
        if (needle.length() == 0) return;
        runBusy("Searching", new Work() {
            @Override public String run(Status status) throws Exception {
                final Set<Integer> found = new HashSet<Integer>();
                int n = 0;
                for (RpfArchive.Entry e : archive.getEntries()) {
                    if (e.directory || e.isResource()) continue;
                    byte[] c = contentFor(e);
                    String s = new String(c, Analyzer.LATIN1).toLowerCase(Locale.ROOT);
                    if (s.indexOf(needle) >= 0) found.add(e.index);
                    n++;
                    if (n % 100 == 0) status.say("Searching\u2026 " + n);
                }
                ui.post(new Runnable() { @Override public void run() { contentMatches = found; } });
                return found.size() + " file(s) contain \"" + query + "\"";
            }
        }, null);
    }

    // ================================================================== saving

    private void doSave() {
        if (busy) { toast("Please wait\u2026"); return; }
        if (pending.isEmpty()) { toast("There are no changes to save."); return; }
        if (scanning) { toast("Still reading the archive - try again in a moment."); return; }
        final File f = archive.getFile();
        new AlertDialog.Builder(this)
                .setTitle("Save changes?")
                .setMessage("This writes " + pending.size() + " changed file(s) into\n" + f.getName()
                        + "\nin the same folder.\n\nA backup copy named " + f.getName()
                        + ".bak is made first (only once, so it always keeps your original).")
                .setPositiveButton("Save", new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface d, int w) { performSave(); }
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    private void performSave() {
        final Map<Integer, byte[]> copy = new LinkedHashMap<Integer, byte[]>(pending);
        runBusy("Saving", new Work() {
            @Override public String run(final Status status) throws Exception {
                File bak = archive.ensureBackup();
                archive.save(copy, new RpfArchive.Progress() {
                    @Override public void onProgress(int done, int total, String what) {
                        status.say("Saving " + (done + 1) + "/" + total + ": " + what);
                    }
                });
                return "Saved " + copy.size() + " change(s). Your original is kept as " + bak.getName();
            }
        }, new Runnable() {
            @Override public void run() {
                for (Integer k : copy.keySet()) pending.remove(k);
                contentMatches = null;
                startScan();
            }
        });
    }

    // ================================================================== background helper

    private void runBusy(final String label, final Work work, final Runnable afterSuccess) {
        if (busy) { toast("Please wait\u2026"); return; }
        busy = true;
        setStatus(label + "\u2026");
        updateHeader();
        new Thread(new Runnable() {
            @Override public void run() {
                String result;
                boolean ok = true;
                try {
                    result = work.run(new Status() {
                        @Override public void say(final String message) {
                            ui.post(new Runnable() { @Override public void run() { setStatus(message); } });
                        }
                    });
                } catch (Throwable t) {
                    ok = false;
                    result = label + " failed: " + t.getMessage();
                }
                final String r = result;
                final boolean success = ok;
                ui.post(new Runnable() {
                    @Override public void run() {
                        busy = false;
                        if (success && afterSuccess != null) afterSuccess.run();
                        setStatus(r);
                        toast(r);
                        refreshList();
                    }
                });
            }
        }).start();
    }

    // ================================================================== back button

    @Override
    public void onBackPressed() {
        if (busy) { toast("Please wait\u2026"); return; }
        if (mode == MODE_BROWSER) {
            if (purpose == PURPOSE_REPLACE) { cancelReplace(); return; }
            File parent = currentDir.getParentFile();
            if (parent == null || currentDir.equals(Environment.getExternalStorageDirectory())) {
                super.onBackPressed();
            } else {
                currentDir = parent;
                showBrowser();
            }
        } else if (mode == MODE_ARCHIVE) {
            if (!pending.isEmpty()) {
                new AlertDialog.Builder(this)
                        .setTitle("Discard changes?")
                        .setMessage("You have " + pending.size() + " change(s) that are not saved yet.")
                        .setPositiveButton("Discard", new DialogInterface.OnClickListener() {
                            @Override public void onClick(DialogInterface d, int w) { leaveArchive(); }
                        })
                        .setNegativeButton("Keep editing", null)
                        .show();
            } else {
                leaveArchive();
            }
        } else {
            super.onBackPressed();
        }
    }

    private void leaveArchive() {
        closeArchive();
        archiveAdapter = null;
        showBrowser();
    }

    // ================================================================== small UI helpers

    private int dp(int v) {
        return (int) (v * getResources().getDisplayMetrics().density + 0.5f);
    }

    private TextView title(String s) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(19);
        t.setTypeface(Typeface.DEFAULT_BOLD);
        t.setPadding(0, 0, 0, dp(6));
        return t;
    }

    private TextView text(String s, int sp) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(sp);
        return t;
    }

    private Button button(String label, View.OnClickListener l) {
        Button b = new Button(this);
        b.setText(label);
        b.setOnClickListener(l);
        return b;
    }

    private Button smallButton(String label, View.OnClickListener l) {
        Button b = button(label, l);
        b.setTextSize(12);
        b.setAllCaps(false);
        return b;
    }

    private LinearLayout.LayoutParams weight() {
        return new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
    }

    private void setStatus(String s) {
        if (statusView != null) statusView.setText(s);
    }

    private void toast(String s) {
        Toast.makeText(this, s, Toast.LENGTH_LONG).show();
    }

    private static String fmtSize(long bytes) {
        if (bytes < 1024) return bytes + " B";
        if (bytes < 1024L * 1024) return String.format(Locale.US, "%.1f KB", bytes / 1024.0);
        return String.format(Locale.US, "%.1f MB", bytes / (1024.0 * 1024.0));
    }

    private static byte[] readAll(File f) throws IOException {
        InputStream in = new FileInputStream(f);
        try {
            byte[] data = new byte[(int) f.length()];
            int pos = 0;
            while (pos < data.length) {
                int n = in.read(data, pos, data.length - pos);
                if (n < 0) throw new IOException("Unexpected end of file");
                pos += n;
            }
            return data;
        } finally {
            in.close();
        }
    }

    private static void writeAll(File f, byte[] data) throws IOException {
        OutputStream out = new FileOutputStream(f);
        try {
            out.write(data);
        } finally {
            out.close();
        }
    }
}
