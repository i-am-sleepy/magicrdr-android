# RPF Editor (Android)

A small Android app for Red Dead Redemption `.rpf` archives (the RPF6 format used by Magic RDR).
It can open an `.rpf`, list its files, export them, edit text files, replace files, and
**save the changes back into the same .rpf in the same folder**.

It is built from the format code in Magic RDR (decryption key, table of contents layout,
Zstandard compression, name hashing). It was tested on a real `tune_android.rpf`.

## How to get the APK (no programming needed) - about 10 minutes

You only need a free GitHub account and a computer's web browser for the upload step.

1. Go to https://github.com and create a free account (or sign in).
2. Click the **+** at the top right -> **New repository**. Name it `RpfEditor`, choose **Public**,
   click **Create repository**.
3. On the new empty repository page click **uploading an existing file**.
4. Unzip this project on your computer. Open the unzipped folder, select EVERYTHING inside it
   (the `app` folder, the `.github` folder, `build.gradle`, `settings.gradle`, `gradle.properties`,
   `.gitignore`, `README.md`) and drag it all into the GitHub page. Wait until every file is listed,
   then click **Commit changes**.
   * If you cannot see the `.github` folder (some computers hide folders that start with a dot),
     skip it for now and do step 4b.
   * 4b. In your repository click **Add file -> Create new file**. In the name box type exactly
     `.github/workflows/build.yml` (typing the slashes creates the folders). Paste the contents of
     the file `build.yml` from this project, then click **Commit changes**.
5. Click the **Actions** tab. A run called **Build APK** starts by itself (if it asks, click the
   green "I understand my workflows" button). Wait 3-8 minutes until it shows a green tick.
6. Click the finished run, scroll down to **Artifacts**, and download **RPF-Editor-APK**.
7. Unzip it. Copy `app-debug.apk` to your phone and open it to install
   (Android will ask you to allow installing from this source - allow it).

If the run shows a red cross, open it, copy the red error text and send it to Claude - it is
normally a one-line fix.

## Using the app

1. On first start tap **Allow access to all files**, switch the permission ON, press Back.
2. Browse to your `.rpf` and tap it. Wait a few seconds while the app reads the files.
3. Tap a file for the menu: **View / edit text**, **Export**, **Replace with a file**, **Details**.
   Changed files get a green pencil. Use **Search inside** to find which file contains some text.
4. Tap **Save changes**. The app first makes `yourfile.rpf.bak` (a one-time backup of the original)
   in the same folder, then writes your changes into the `.rpf`.

Exports go to a folder next to the `.rpf` named `<name>_extracted`.

## Good to know

* Most names inside the archive are stored only as hash numbers (like `0x07A40D6C`), so the app shows
  the type and a preview of each file, and recovers real names where it can (material files).
* Android 11 and newer block apps from reading the `Android/data` and `Android/obb` folders, even
  with "All files access". If your `.rpf` is there, copy it to another folder (for example Download)
  with a file manager, edit it there, then copy it back.
* Resource files (console-format textures and models) can be exported but not replaced.
* Always keep the `.bak` backup until you have confirmed the game still works with your edit.
