# RPF Editor (Android)

A small Android app for Red Dead Redemption `.rpf` archives (the RPF6 format used by Magic RDR).
It can open an `.rpf`, list its files, export them, edit text files, replace files, and
**save the changes back into the same .rpf in the same folder**.

It is built from the format code in Magic RDR (decryption key, table of contents layout,
Zstandard compression, name hashing). It was tested on a real `tune_android.rpf`.

## How to get the APK (works from a phone browser)

1. Create a free GitHub account and a new repository (Public).
2. In the repository tap **Add file -> Upload files**, pick this project's `.zip` from your phone
   (do NOT unzip it) and **Commit changes**.
3. Tap **Add file -> Create new file**, type the name `.github/workflows/build.yml`, paste the contents of
   `build.yml` (the workflow that extracts the zip and builds it), and **Commit changes**.
4. Open the **Actions** tab and wait a few minutes for the green tick.
5. Go back to the repository's main page, open **Releases**, tap `RpfEditor.apk`, and install it
   (allow "install from this source" when Android asks).

If a run shows a red cross, open it, copy the red error text and send it to Claude.

## Using the app

1. On first start tap **Allow access to all files**, switch the permission ON, press Back.
2. Browse to your `.rpf` and tap it. Wait a few seconds while the app reads the files.
3. Tap a file for the menu: **View / edit text**, **Export**, **Replace with a file**, **Details**.
   Changed files get a green pencil. Use **Search inside** to find which file contains some text.
4. Tap **Save changes**. The app first makes `yourfile.rpf.bak` (a one-time backup of the original)
   in the same folder, then writes your changes into the `.rpf`.

Exports go to a folder next to the `.rpf` named `<name>_extracted`. The archive's own folder
structure is kept (folders are named by their hash, e.g. `A5B6C7D8`), because the same file name can exist
in several folders of the archive.

### Rebuilding the .rpf from your edited `_extracted` folder

1. Tap **Export all**. Edit the files you want in the `_extracted` folder with any text editor app
   (keep the file names and keep the files inside their folders).
2. Back in RPF Editor tap **Import folder**. It opens `_extracted` for you - tap **Use this folder**.
3. The app compares every file with what is in the archive and queues only the ones you changed
   (they get a green pencil). Then tap **Save changes**.

## Good to know

* Most names inside the archive are stored only as hash numbers (like `0x07A40D6C`), so the app shows
  the type and a preview of each file, and recovers real names where it can (material files).
* Android 11 and newer block apps from reading the `Android/data` and `Android/obb` folders, even
  with "All files access". If your `.rpf` is there, copy it to another folder (for example Download)
  with a file manager, edit it there, then copy it back.
* Resource files (console-format textures and models) can be exported but not replaced.
* Always keep the `.bak` backup until you have confirmed the game still works with your edit.
